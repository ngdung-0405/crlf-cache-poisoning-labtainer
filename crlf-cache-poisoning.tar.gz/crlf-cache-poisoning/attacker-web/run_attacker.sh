#!/bin/bash
echo "CRLF cache-poisoning sender ready."
exec python3 /home/ubuntu/attacker_poison.py
