#!/bin/bash
chmod +x /home/ubuntu/*.py /home/ubuntu/*.sh
chown -R ubuntu:ubuntu /home/ubuntu
