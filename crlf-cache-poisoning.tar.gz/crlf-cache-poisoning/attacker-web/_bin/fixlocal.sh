#!/bin/bash
chmod 644 /home/ubuntu/payload_notes.txt 2>/dev/null || true
