Victim workflow:
python3 victim_visit.py

Use the default URL:
http://192.168.10.2/page?lang=vi

Then type:
VISIT

The victim script performs a real HTTP request and checks its own CookieJar.
