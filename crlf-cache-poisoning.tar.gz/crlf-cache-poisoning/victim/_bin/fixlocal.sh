#!/bin/bash
rm -f /home/ubuntu/cookies.txt
