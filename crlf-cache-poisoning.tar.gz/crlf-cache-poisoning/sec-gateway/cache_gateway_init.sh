#!/bin/sh
### BEGIN INIT INFO
# Provides:          cache-gateway
# Required-Start:    $network
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Reverse Proxy Web Cache & Suricata Monitor Daemon
### END INIT INFO

DAEMON="/usr/local/bin/cache_gateway_daemon.py"
PIDFILE="/var/run/cache-gateway.pid"

case "$1" in
  start)
    echo "Starting cache-gateway..."
    if [ -f "$PIDFILE" ] && kill -0 $(cat "$PIDFILE") 2>/dev/null; then
        echo "cache-gateway is already running."
        exit 0
    fi
    nohup /usr/bin/python3 "$DAEMON" >/var/log/sec-gateway/daemon.err 2>&1 &
    echo $! > "$PIDFILE"
    ;;
  stop)
    echo "Stopping cache-gateway..."
    if [ -f "$PIDFILE" ]; then
        kill $(cat "$PIDFILE") 2>/dev/null
        rm -f "$PIDFILE"
    fi
    pkill -f cache_gateway_daemon.py 2>/dev/null || true
    ;;
  restart)
    $0 stop
    sleep 1
    $0 start
    ;;
  status)
    if [ -f "$PIDFILE" ] && kill -0 $(cat "$PIDFILE") 2>/dev/null; then
        echo "cache-gateway is running (PID $(cat $PIDFILE))"
    else
        echo "cache-gateway is stopped"
        exit 1
    fi
    ;;
  *)
    echo "Usage: service cache-gateway {start|stop|restart|status}"
    exit 1
    ;;
esac
exit 0
