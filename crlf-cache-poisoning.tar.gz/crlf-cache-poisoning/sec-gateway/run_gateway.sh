#!/bin/bash
set -u
rm -f /home/ubuntu/gateway-events.log /home/ubuntu/cache-state.txt
echo "SEC_GATEWAY_CACHE_STARTED=yes"
echo "Gateway starts with an empty cache."
exec python3 /home/ubuntu/cache_proxy.py
