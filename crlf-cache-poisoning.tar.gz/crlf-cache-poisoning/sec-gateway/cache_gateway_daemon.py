#!/usr/bin/env python3
import os
import socket
import json
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer
from datetime import datetime

CONF_PATH = "/etc/sec-gateway/cache.conf"
CACHE_LOG = "/var/log/sec-gateway/cache.log"
SURICATA_LOG = "/var/log/suricata/fast.log"

WEB_CACHE = {}

def load_config():
    cfg = {
        "CACHE_POLICY": "vulnerable_cache",
        "UPSTREAM_HOST": "172.20.0.10",
        "UPSTREAM_PORT": "80"
    }
    if os.path.exists(CONF_PATH):
        with open(CONF_PATH, "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    cfg[k.strip()] = v.strip()
    return cfg

def write_cache_log(entry):
    os.makedirs(os.path.dirname(CACHE_LOG), exist_ok=True)
    with open(CACHE_LOG, "a") as f:
        f.write(entry + "\n")

def write_suricata_alert(src_ip, dst_ip, raw_path):
    os.makedirs(os.path.dirname(SURICATA_LOG), exist_ok=True)
    ts = datetime.utcnow().strftime("%m/%d/%Y-%H:%M:%S.%f")
    lower_path = raw_path.lower()
    with open(SURICATA_LOG, "a") as f:
        if "%0d" in lower_path or "%0a" in lower_path:
            f.write(
                f"{ts}  [**] [1:3000101:1] [SURICATA-NIDS] CRLF Injection / HTTP Response Splitting Detected in Query URI (%0d%0a) [**] "
                f"[Classification: Web Application Attack] [Priority: 1] {{TCP}} {src_ip}:52410 -> {dst_ip}:80 uri=\"{raw_path}\"\n"
            )
        if "set-cookie" in lower_path:
            f.write(
                f"{ts}  [**] [1:3000102:1] [SURICATA-NIDS] Web Cache Poisoning Attempt - Injected Set-Cookie Header via CRLF [**] "
                f"[Classification: Web Application Attack] [Priority: 1] {{TCP}} {src_ip}:52410 -> {dst_ip}:80 uri=\"{raw_path}\"\n"
            )

def compute_normalized_cache_key(raw_path):
    parsed = urllib.parse.urlparse(raw_path)
    params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    if parsed.path == "/page":
        raw_lang = params.get("lang", ["vi"])[0]
        normalized_lang = raw_lang.split("\r")[0].split("\n")[0].strip()
        return f"/page?lang={normalized_lang}"
    return parsed.path

def fetch_raw_upstream(host, port, raw_path, client_headers):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(5.0)
    s.connect((host, int(port)))
    req_lines = [f"GET {raw_path} HTTP/1.0", f"Host: {host}"]
    if "Cookie" in client_headers:
        req_lines.append(f"Cookie: {client_headers['Cookie']}")
    if "User-Agent" in client_headers:
        req_lines.append(f"User-Agent: {client_headers['User-Agent']}")
    req_data = ("\r\n".join(req_lines) + "\r\n\r\n").encode("utf-8")
    s.sendall(req_data)

    chunks = []
    while True:
        data = s.recv(4096)
        if not data:
            break
        chunks.append(data)
    s.close()
    raw_resp = b"".join(chunks)

    sep = b"\r\n\r\n"
    if sep in raw_resp:
        hdr_bytes, body = raw_resp.split(sep, 1)
    else:
        hdr_bytes, body = raw_resp, b""

    lines = hdr_bytes.decode("utf-8", errors="replace").split("\r\n")
    status_line = lines[0] if lines else "HTTP/1.0 200 OK"
    parts = status_line.split(" ", 2)
    status_code = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 200

    headers = []
    for line in lines[1:]:
        if ":" in line:
            k, v = line.split(":", 1)
            headers.append((k.strip(), v.strip()))
    return status_code, headers, body

class CacheGatewayHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        global WEB_CACHE
        cfg = load_config()
        policy = cfg.get("CACHE_POLICY", "vulnerable_cache")
        upstream_host = cfg.get("UPSTREAM_HOST", "172.20.0.10")
        upstream_port = int(cfg.get("UPSTREAM_PORT", "80"))
        ts = datetime.utcnow().strftime("%d/%b/%Y:%H:%M:%S +0000")
        client_ip = self.client_address[0]
        raw_path = self.path

        if "%0d" in raw_path.lower() or "%0a" in raw_path.lower():
            write_suricata_alert(client_ip, "192.168.10.2", raw_path)

        if raw_path.startswith("/cache/purge"):
            WEB_CACHE.clear()
            write_cache_log(f"[{ts}] SEC_GATEWAY client={client_ip} action=CACHE_PURGED policy={policy}")
            body = json.dumps({"cache_status": "PURGED", "policy": policy}, indent=2).encode("utf-8") + b"\n"
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        if raw_path.startswith("/cache/status"):
            summary = {}
            for k, v in WEB_CACHE.items():
                summary[k] = {
                    "cached_headers": v["headers"],
                    "contains_injected_set_cookie": any(hk.lower() == "set-cookie" for hk, _ in v["headers"])
                }
            body = json.dumps({"cache_policy": policy, "entries": summary}, indent=2).encode("utf-8") + b"\n"
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        if policy == "secure_no_setcookie":
            for k in list(WEB_CACHE.keys()):
                if any(hk.lower() == "set-cookie" for hk, _ in WEB_CACHE[k]["headers"]):
                    del WEB_CACHE[k]

        cache_key = compute_normalized_cache_key(raw_path)
        is_cacheable_endpoint = raw_path.startswith("/page")
        has_crlf_in_req = ("%0d" in raw_path.lower()) or ("%0a" in raw_path.lower())

        if is_cacheable_endpoint and (cache_key in WEB_CACHE) and not has_crlf_in_req:
            entry = WEB_CACHE[cache_key]
            has_poisoned_cookie = any(hk.lower() == "set-cookie" and "admin_access=true" in hv for hk, hv in entry["headers"])
            write_cache_log(
                f"[{ts}] SEC_GATEWAY client={client_ip} raw_path=\"{raw_path}\" cache_key=\"{cache_key}\" "
                f"X_CACHE=HIT policy={policy} SERVED_POISONED_COOKIE={'YES' if has_poisoned_cookie else 'NO'}"
            )
            self.send_response(entry["status"])
            self.send_header("X-Cache", "HIT")
            self.send_header("X-Cache-Key", cache_key)
            self.send_header("X-Cache-Policy", policy)
            for hk, hv in entry["headers"]:
                if hk.lower() not in ("server", "date", "content-length"):
                    self.send_header(hk, hv)
            self.send_header("Content-Length", str(len(entry["body"])))
            self.end_headers()
            self.wfile.write(entry["body"])
            return

        status_code, resp_headers, resp_body = fetch_raw_upstream(upstream_host, upstream_port, raw_path, self.headers)
        has_set_cookie = any(hk.lower() == "set-cookie" for hk, _ in resp_headers)
        has_poisoned_cookie = any(hk.lower() == "set-cookie" and "admin_access=true" in hv for hk, hv in resp_headers)

        cache_action = "BYPASS"
        if is_cacheable_endpoint and status_code == 200:
            if policy == "secure_no_setcookie" and (has_set_cookie or has_crlf_in_req):
                cache_action = "SKIP_UNSAFE_SET_COOKIE"
                write_cache_log(
                    f"[{ts}] SEC_GATEWAY client={client_ip} raw_path=\"{raw_path}\" cache_key=\"{cache_key}\" "
                    f"X_CACHE=MISS policy={policy} action=CACHE_STORE_BLOCKED_RFC7234"
                )
            else:
                WEB_CACHE[cache_key] = {
                    "status": status_code,
                    "headers": resp_headers,
                    "body": resp_body
                }
                cache_action = "STORED"
                write_cache_log(
                    f"[{ts}] SEC_GATEWAY client={client_ip} raw_path=\"{raw_path}\" cache_key=\"{cache_key}\" "
                    f"X_CACHE=MISS policy={policy} action=CACHE_STORED CACHE_POISONED={'YES' if has_poisoned_cookie else 'NO'}"
                )
        else:
            write_cache_log(
                f"[{ts}] SEC_GATEWAY client={client_ip} raw_path=\"{raw_path}\" status={status_code} "
                f"X_CACHE=MISS policy={policy} action={cache_action}"
            )

        self.send_response(status_code)
        self.send_header("X-Cache", "MISS")
        self.send_header("X-Cache-Key", cache_key)
        self.send_header("X-Cache-Policy", policy)
        self.send_header("X-Cache-Store-Action", cache_action)
        for hk, hv in resp_headers:
            if hk.lower() not in ("server", "date", "content-length"):
                self.send_header(hk, hv)
        self.send_header("Content-Length", str(len(resp_body)))
        self.end_headers()
        self.wfile.write(resp_body)

if __name__ == "__main__":
    os.makedirs(os.path.dirname(CACHE_LOG), exist_ok=True)
    os.makedirs(os.path.dirname(SURICATA_LOG), exist_ok=True)
    for p in (CACHE_LOG, SURICATA_LOG):
        if not os.path.exists(p):
            open(p, "a").close()
    server = HTTPServer(("0.0.0.0", 80), CacheGatewayHandler)
    server.serve_forever()
