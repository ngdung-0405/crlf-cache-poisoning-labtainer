#!/usr/bin/env python3
rules = open("/home/ubuntu/crlf.rules", encoding="utf-8").read().lower()

required = [
    "http.raw_uri",
    "%0d%0a",
    "%0a",
    "%e5%98%8d%e5%98%8a",
    "sid:3003001"
]

ok = all(item in rules for item in required)
print("suricata_rule_created=yes" if ok else "suricata_rule_created=no")
