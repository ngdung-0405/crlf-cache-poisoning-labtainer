#!/usr/bin/env python3
from pathlib import Path

rules_path = Path("/home/ubuntu/crlf.rules")
events_path = Path("/home/ubuntu/gateway-events.log")

rules = rules_path.read_text(encoding="utf-8").lower()
events = (
    events_path.read_text(encoding="utf-8", errors="ignore").lower()
    if events_path.exists()
    else ""
)

rule_valid = (
    "http.raw_uri" in rules
    and "%0d%0a" in rules
    and "%0a" in rules
    and "sid:3003001" in rules
)

# Chỉ đạt khi request thật từ attacker đã đi qua gateway.
request_seen = (
    "%0d%0a" in events
    or "%e5%98%8d%e5%98%8a" in events
)

print(
    "crlf_injection_detected=yes"
    if rule_valid and request_seen
    else "crlf_injection_detected=no"
)

if not request_seen:
    print("No real CRLF request recorded yet. Run attacker_poison.py first.")
