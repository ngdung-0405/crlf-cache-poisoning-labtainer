#!/usr/bin/env python3
import os
import socketserver
from urllib.parse import urlsplit, parse_qs

MODE = os.environ.get("APP_MODE", "vulnerable")
ALLOWED = {"vi", "en", "fr"}

def read_headers(sock):
    data = b""
    sock.settimeout(5)

    while b"\r\n\r\n" not in data and len(data) < 65535:
        chunk = sock.recv(4096)
        if not chunk:
            break
        data += chunk

    return data

class Handler(socketserver.BaseRequestHandler):
    def handle(self):
        request = read_headers(self.request)
        if not request:
            return

        first_line = request.split(b"\r\n", 1)[0].decode(
            "iso-8859-1", errors="replace"
        )
        parts = first_line.split(" ")

        if len(parts) < 2:
            return

        request_target = parts[1]
        parsed = urlsplit(request_target)

        if parsed.path != "/page":
            self.request.sendall(
                b"HTTP/1.1 404 Not Found\r\n"
                b"Content-Length: 0\r\n"
                b"Connection: close\r\n\r\n"
            )
            return

        lang = parse_qs(parsed.query, keep_blank_values=True).get(
            "lang", ["vi"]
        )[0]

        print("\n[Target] Request:", first_line, flush=True)
        print("[Target] lang decoded:", repr(lang), flush=True)

        if MODE == "secure" and lang not in ALLOWED:
            body = b"Rejected language value\n"
            response = (
                b"HTTP/1.1 400 Bad Request\r\n"
                b"Content-Type: text/plain\r\n"
                b"Content-Length: " + str(len(body)).encode() + b"\r\n"
                b"Connection: close\r\n\r\n" + body
            )
            self.request.sendall(response)
            print("[Target] Secure mode rejected input.", flush=True)
            return

        if "\r" in lang or "\n" in lang:
            print("[Target] CRLF FOUND - injecting a new response header.", flush=True)

        body = b"Training page loaded.\n"

        # Cố ý tạo raw HTTP response để minh hoạ HTTP Response Splitting.
        response = (
            b"HTTP/1.1 200 OK\r\n"
            b"Content-Type: text/plain\r\n"
            + b"Content-Language: "
            + lang.encode("iso-8859-1", errors="replace")
            + b"\r\n"
            + b"Cache-Control: public, max-age=120\r\n"
            + b"X-Lab-Origin: target-web\r\n"
            + b"Content-Length: " + str(len(body)).encode() + b"\r\n"
            + b"Connection: close\r\n\r\n"
            + body
        )

        self.request.sendall(response)

class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True

print("target_started=yes", flush=True)
print("TARGET WEB CRLF TRAINING SERVICE RUNNING", flush=True)
Server(("0.0.0.0", 80), Handler).serve_forever()
