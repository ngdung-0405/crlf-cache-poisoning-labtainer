Target web:
./run_target.sh

Secure validation:
./run_target_secure.sh

Vulnerable endpoint:
http://172.20.0.10/page?lang=vi
