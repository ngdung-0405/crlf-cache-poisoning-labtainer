#!/bin/bash
sudo mkdir -p /var/log/target-portal /etc/target-portal
sudo touch /var/log/target-portal/access.log
sudo chmod -R 755 /var/log/target-portal
sudo cp /home/ubuntu/portal_daemon.py /usr/local/bin/portal_daemon.py
sudo chmod +x /usr/local/bin/portal_daemon.py
sudo cp /home/ubuntu/target_portal_init.sh /etc/init.d/target-portal
sudo chmod +x /etc/init.d/target-portal
sudo service target-portal start || true

if ! grep -q "portal_daemon.py" /home/ubuntu/.bashrc; then
cat << 'BRC' >> /home/ubuntu/.bashrc
if ! pgrep -f portal_daemon.py >/dev/null 2>&1; then
    sudo service target-portal start >/dev/null 2>&1 || true
fi
BRC
fi
