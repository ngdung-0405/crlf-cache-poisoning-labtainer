#!/bin/bash
echo "target_started=yes"
echo "TARGET_CRLF_MODE=RAW"
exec python3 /home/ubuntu/target_server.py
