#!/bin/sh
### BEGIN INIT INFO
# Provides:          target-portal
# Required-Start:    $network
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Target Portal Web Daemon
### END INIT INFO

DAEMON="/usr/local/bin/portal_daemon.py"
PIDFILE="/var/run/target-portal.pid"

case "$1" in
  start)
    echo "Starting target-portal..."
    if [ -f "$PIDFILE" ] && kill -0 $(cat "$PIDFILE") 2>/dev/null; then
        echo "target-portal is already running."
        exit 0
    fi
    nohup /usr/bin/python3 "$DAEMON" >/var/log/target-portal/daemon.err 2>&1 &
    echo $! > "$PIDFILE"
    ;;
  stop)
    echo "Stopping target-portal..."
    if [ -f "$PIDFILE" ]; then
        kill $(cat "$PIDFILE") 2>/dev/null
        rm -f "$PIDFILE"
    fi
    pkill -f portal_daemon.py 2>/dev/null || true
    ;;
  restart)
    $0 stop
    sleep 1
    $0 start
    ;;
  status)
    if [ -f "$PIDFILE" ] && kill -0 $(cat "$PIDFILE") 2>/dev/null; then
        echo "target-portal is running (PID $(cat $PIDFILE))"
    else
        echo "target-portal is stopped"
        exit 1
    fi
    ;;
  *)
    echo "Usage: service target-portal {start|stop|restart|status}"
    exit 1
    ;;
esac
exit 0
