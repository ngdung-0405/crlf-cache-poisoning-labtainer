#!/usr/bin/env python3
import os
import json
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer
from datetime import datetime

CONF_PATH = "/etc/target-portal/portal.conf"
LOG_DIR = "/var/log/target-portal"
ACCESS_LOG = os.path.join(LOG_DIR, "access.log")

def load_config():
    cfg = {
        "CRLF_PROTECTION_MODE": "vulnerable",
        "ALLOWED_LANGS": "vi,en,fr"
    }
    if os.path.exists(CONF_PATH):
        with open(CONF_PATH, "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    cfg[k.strip()] = v.strip()
    return cfg

def write_log(entry):
    os.makedirs(LOG_DIR, exist_ok=True)
    with open(ACCESS_LOG, "a") as f:
        f.write(entry + "\n")

class TargetPortalHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        cfg = load_config()
        mode = cfg.get("CRLF_PROTECTION_MODE", "vulnerable")
        allowed_langs = [x.strip() for x in cfg.get("ALLOWED_LANGS", "vi,en,fr").split(",")]
        ts = datetime.utcnow().strftime("%d/%b/%Y:%H:%M:%S +0000")

        parsed = urllib.parse.urlparse(self.path)
        raw_query = parsed.query
        params = urllib.parse.parse_qs(raw_query, keep_blank_values=True)
        decoded_lang = params.get("lang", ["vi"])[0]
        cookie_hdr = self.headers.get("Cookie", "")

        has_crlf = ("\r" in decoded_lang) or ("\n" in decoded_lang) or ("%0d" in raw_query.lower()) or ("%0a" in raw_query.lower())

        if parsed.path == "/page":
            if mode == "strict_sanitize":
                if has_crlf or decoded_lang not in allowed_langs:
                    write_log(f"[{ts}] TARGET_PORTAL path=/page mode={mode} status=400 action=CRLF_INJECTION_BLOCKED raw_query={raw_query}")
                    body = json.dumps({
                        "error": "400_CRLF_INJECTION_BLOCKED",
                        "message": "CR/LF control characters (\\r\\n) are strictly prohibited in HTTP response headers.",
                        "allowed_languages": allowed_langs,
                        "protection_mode": mode
                    }, indent=2).encode("utf-8") + b"\n"
                    self.send_response(400)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("X-CRLF-Protection", "strict_sanitize")
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                    return

                clean_lang = decoded_lang
                write_log(f"[{ts}] TARGET_PORTAL path=/page mode={mode} status=200 lang={clean_lang} CRLF_INJECTED=NO")
                body = (
                    f"<!DOCTYPE html>\n<html>\n<head><title>PTIT E-Portal ({clean_lang.upper()})</title></head>\n"
                    f"<body>\n  <h1>PTIT Academic Portal - Language: {clean_lang}</h1>\n"
                    f"  <p>Welcome to the internal student portal (Sanitized Header Mode).</p>\n</body>\n</html>\n"
                ).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Language", clean_lang)
                self.send_header("X-CRLF-Protection", "strict_sanitize")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            # VULNERABLE MODE: Construct raw HTTP response header allowing \r\n header splitting!
            base_lang = decoded_lang.split("\r")[0].split("\n")[0]
            if has_crlf:
                write_log(f"[{ts}] TARGET_PORTAL path=/page mode={mode} status=200 CRLF_INJECTED=YES raw_query={raw_query}")
            else:
                write_log(f"[{ts}] TARGET_PORTAL path=/page mode={mode} status=200 lang={base_lang} CRLF_INJECTED=NO")

            body = (
                f"<!DOCTYPE html>\n<html>\n<head><title>PTIT E-Portal ({base_lang.upper()})</title></head>\n"
                f"<body>\n  <h1>PTIT Academic Portal - Language: {base_lang}</h1>\n"
                f"  <p>Welcome to the internal student portal.</p>\n</body>\n</html>\n"
            ).encode("utf-8")

            raw_response_headers = (
                f"HTTP/1.0 200 OK\r\n"
                f"Server: TargetPortal/2.4\r\n"
                f"Content-Type: text/html; charset=utf-8\r\n"
                f"Content-Language: {decoded_lang}\r\n"
                f"X-CRLF-Protection: {mode}\r\n"
                f"Content-Length: {len(body)}\r\n"
                f"\r\n"
            ).encode("utf-8")
            self.wfile.write(raw_response_headers + body)
            return

        elif parsed.path == "/profile":
            poisoned = "admin_access=true" in cookie_hdr
            write_log(
                f"[{ts}] TARGET_PORTAL path=/profile status=200 cookie=\"{cookie_hdr}\" "
                f"VICTIM_POISONED_COOKIE_ACTIVE={'YES' if poisoned else 'NO'}"
            )
            body = json.dumps({
                "endpoint": "/profile",
                "received_cookie": cookie_hdr if cookie_hdr else "NONE",
                "admin_access_cookie_present": poisoned,
                "security_notice": (
                    "WARNING: Client transmitted poisoned cookie admin_access=true injected via Web Cache Poisoning!"
                    if poisoned else "Clean client session."
                )
            }, indent=2).encode("utf-8") + b"\n"
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        else:
            body = b'{"status":"target-portal online","endpoints":["/page?lang=vi","/profile"]}\n'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

if __name__ == "__main__":
    os.makedirs(LOG_DIR, exist_ok=True)
    if not os.path.exists(ACCESS_LOG):
        open(ACCESS_LOG, "a").close()
    server = HTTPServer(("0.0.0.0", 80), TargetPortalHandler)
    server.serve_forever()
